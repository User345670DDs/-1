﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (НедвижемостьEntities Voz = new НедвижемостьEntities())
                {
                    Клиент a = new Клиент()
                    {
                        Фамилия = Convert.ToString(textBox1.Text),

                        Имя = Convert.ToString(textBox2.Text),

                        Отчество = Convert.ToString(textBox3.Text),
                        Номер_телефона = Convert.ToString(textBox4.Text),

                        Электронная_почта = Convert.ToString(textBox5.Text),
                    };
                    Voz.Клиент.Add(a);
                    Voz.SaveChanges();
                    MessageBox.Show("Клиент добавлен");
                }
            }
            catch { MessageBox.Show("ОШибка"); }
        }
    }
}
