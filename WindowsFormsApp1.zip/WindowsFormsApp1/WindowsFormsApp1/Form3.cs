﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "недвижемостьDataSet1.Клиент". При необходимости она может быть перемещена или удалена.
            this.клиентTableAdapter.Fill(this.недвижемостьDataSet1.Клиент);

        }


        private void button1_Click(object sender, EventArgs e)
        {
            Form4 Form1 = new Form4();
            Form1.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            Form3 Form = new Form3();
            this.Hide();
            Form.Show();

        }
        private void button3_Click(object sender, EventArgs e)
        {
            using (var db = new НедвижемостьEntities())
            {
                if(dataGridView1.SelectedRows.Count > 0)
                {
                    int index = dataGridView1.SelectedRows[0].Index;
                    int id = 0;
                    bool converted = Int32.TryParse(dataGridView1[0, index].Value.ToString(), out id);
                    if (converted == false)
                        return;
                    Клиент users = db.Клиент.Find(id);
                    db.Клиент.Remove(users);
                    db.SaveChanges();
                    MessageBox.Show("Запись удалена");
                }
            }

        }

        
        
    }
}
